INTROIFY — LOGO AND FAVICON

Current approved main-site logo: locked option 13.
All artwork is static. SVG and transparent PNG files retain the approved lettering and symbol.

For a Razorpay business-logo upload, use logos/introify-logo-white-background.png.
Use logos/introify-logo-light.png or .svg on light backgrounds.
Use logos/introify-logo-dark.png or .svg on dark backgrounds.
Use favicons/favicon.ico or favicon.svg for browser tabs.
PNG favicon sizes: 16, 32, 48, 180, 192, 256 and 512 pixels.
apple-touch-icon.png has a white background for an iOS home-screen icon.

Public policy pages:
https://introify.com/terms
https://introify.com/refund-policy
https://introify.com/privacy
https://introify.com/contact

Policy publication does not itself establish payment-provider approval. Complete the public operator, support and refund terms before submitting draft policies for review.
